
public class Main {

    public static void main(String[] Args) {
        String host = "Banco";
        String user = "Administrador";
        String pass = "1234";
        int puerto = 1527;
        Persistencia p = new Persistencia(host, user, pass, puerto);
        MenuPrincipal v = new MenuPrincipal(p);
    }

}
