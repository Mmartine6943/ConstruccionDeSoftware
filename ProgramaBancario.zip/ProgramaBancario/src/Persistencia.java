
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Persistencia {

    private String host;
    private String user;
    private String pass;
    private int puerto;
    private Connection conn;

    public Persistencia(String host, String user, String pass, int puerto) {
        this.host = host;
        this.user = user;
        this.pass = pass;
        this.puerto = puerto;
        String dbURL = "jdbc:derby://localhost:" + this.puerto + "/" + this.host + ";user=" + this.user + ";password=" + this.pass;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
            conn = DriverManager.getConnection(dbURL);
            System.out.println("Conexion establecida.");
        } catch (Exception e) {
            System.out.println("Error en Constructor de la clase Persistencia.");
            System.out.println("Referencia: " + e.getMessage());
        }

    }

    public boolean registrarCliente(String cedula, String nombre, String telefono, String correo) {
        try {
            String query = "INSERT INTO ADMINISTRADOR.CLIENTE (IDCLIENTE, NOMBRECLIENTE, TELEFONOCLIENTE, CORREOCLIENTE) \n"
                    + "	VALUES (" + cedula + ", '" + nombre + "', '" + telefono + "', '" + correo + "')\n"
                    + "";
            Statement st = conn.createStatement();
            st.execute(query);
            return true;
        } catch (Exception e) {
            System.out.println("Error en (Metodo) de la clase (Clase).");
            System.out.println("Referencia: " + e.getMessage());
        }
        return false;
    }

    public int getTotalRegistros(String cuenta) {
        int total = 0;
        try {
            String query = "SELECT COUNT(*) FROM ADMINISTRADOR." + cuenta.toUpperCase() + "";
            Statement st = conn.createStatement();
            st.execute(query);
        } catch (Exception e) {
            System.out.println("Error en (Metodo) de la clase (Clase).");
            System.out.println("Referencia: " + e.getMessage());
        }
        return total;
    }

    public boolean registrarCuenta(int idCuenta, String cedula, String clave, int saldo) {
        try {
            String query = "INSERT INTO ADMINISTRADOR.CUENTA (IDCUENTA, IDCLIENTE, SALDOCUENTA, CLAVECUENTA) \n"
                    + "	VALUES (" + idCuenta + ", " + cedula + ", " + saldo + ", '" + clave + "')\n"
                    + "";
            Statement st = conn.createStatement();
            st.execute(query);
            return true;
        } catch (Exception e) {
            System.out.println("Error en (Metodo) de la clase (Clase).");
            System.out.println("Referencia: " + e.getMessage());
        }
        return false;
    }

    public String consultarSaldo(String cedula, String clave) {
        String respuesta = "";
        if (esClaveCorrecta(cedula, clave)) {
            try {
                String query = "SELECT IDCUENTA, SALDOCUENTA FROM ADMINISTRADOR.CUENTA WHERE IDCLIENTE=" + cedula + " AND CAST(CLAVECUENTA AS VARCHAR(128)) = '" + clave + "'";
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);
                if(rs.next()){
                    respuesta = "IDCuenta: "+rs.getString(1)+"\n"+"Saldo: "+rs.getString(2);
                }
            } catch (Exception e) {
                System.out.println("Error en esClaveCorrecta de la clase (Clase).");
                System.out.println("Referencia: " + e.getMessage());
            }
        } else {
            respuesta = "No es correcta la clave";
        }
        return respuesta;
    }

    public boolean esClaveCorrecta(String cedula, String clave) {
        try {
            String query = "SELECT * FROM ADMINISTRADOR.CUENTA WHERE IDCLIENTE=" + cedula + " AND CAST(CLAVECUENTA AS VARCHAR(128)) = '" + clave + "'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            return rs.next();
        } catch (Exception e) {
            System.out.println("Error en esClaveCorrecta de la clase (Clase).");
            System.out.println("Referencia: " + e.getMessage());
        }
        return false;
    }

    public int consultarSaldoEnEntero(String cedula, String clave) {
        int saldo = 0;
        if (esClaveCorrecta(cedula, clave)) {
            try {
                String query = "SELECT SALDOCUENTA FROM ADMINISTRADOR.CUENTA WHERE IDCLIENTE=" + cedula + " AND CAST(CLAVECUENTA AS VARCHAR(128)) = '" + clave + "'";
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);
                if(rs.next()){
                    saldo = Integer.parseInt(rs.getString(1));
                }
            } catch (Exception e) {
                System.out.println("Error en esClaveCorrecta de la clase (Clase).");
                System.out.println("Referencia: " + e.getMessage());
            }
        } else {
            saldo = 0;
        }
        return saldo;
    }

    public void actualizarSaldo(String cedula, int saldo) {
        try {
            String query = "UPDATE ADMINISTRADOR.CUENTA SET SALDOCUENTA="+saldo+" WHERE IDCLIENTE="+cedula;            
            Statement st = conn.createStatement();
            st.execute(query);
        } catch (Exception e) {
            System.out.println("Error en esClaveCorrecta de la clase (Clase).");
            System.out.println("Referencia: " + e.getMessage());
        }
    }

    public boolean actualizarClave(String cedula, String clave, String nueva) {
        try {
            String query = "UPDATE ADMINISTRADOR.CUENTA SET CLAVECUENTA='"+nueva+"' WHERE IDCLIENTE="+cedula;            
            Statement st = conn.createStatement();
            st.execute(query);
            return true;
        } catch (Exception e) {
            System.out.println("Error en esClaveCorrecta de la clase (Clase).");
            System.out.println("Referencia: " + e.getMessage());
        }
        return false;
    }
    
}
